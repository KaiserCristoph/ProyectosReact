import { AppRouter } from './routers/AppRouter';


export const HeroesApp = () => {
    return (
        <AppRouter />
    )
}
